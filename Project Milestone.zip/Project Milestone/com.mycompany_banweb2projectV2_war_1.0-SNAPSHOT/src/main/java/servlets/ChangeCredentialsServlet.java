package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/change-pin")
public class ChangeCredentialsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Handles password change
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        //String user_id = request.getParameter("currentUser");
        
        // get current session
        HttpSession session = request.getSession(false);
        
        // If the user somehow reached this without logging in, send them back
        if (session == null || session.getAttribute("userId") == null) {
            response.sendRedirect("login.html");
            return;
        }
        
        // get user_id from current sesssion
        int Integer_user_id = (int) session.getAttribute("userId");
        String user_id = String.valueOf(Integer_user_id);
        
        
        String curr_pin = request.getParameter("currentPin");
        String new_pin = request.getParameter("newPin");
        String conf_pin = request.getParameter("confirmPin");
        
        if(user_id == null || curr_pin == null || new_pin == null || conf_pin == null) {
            out.println("Please enter student number and new password!");
            return;
        }

        // Make sure new_pin and conf_pin are the same
        if (!(new_pin.equals(conf_pin))){
            out.println("Then new Pin and Re enterd Pin must match");
            return;
        }
        
        
        try {
            // connect to database
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/banweb2db", 
                "root",
                "1234"
            );

            
            // Check current Pin
            PreparedStatement stmt = con.prepareStatement(
                "SELECT pass FROM users WHERE id=?"
            );
            stmt.setString(1, user_id);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                if (curr_pin.equals(rs.getString(1))){
                    
                } else {
                    out.println("<h2>Incorrect Pin!.</h2>");
                    con.close();
                    return;
                }
                
            } else {
                out.println("<h2>User not found!.</h2>");
                con.close();
                return;
            }
            
            

            
            // update pin
            stmt = con.prepareStatement(
                "UPDATE users SET pass=? WHERE id=?"
            );
            stmt.setString(1, new_pin);
            stmt.setString(2, user_id);

            int rows = stmt.executeUpdate();
            if(rows > 0) {
                out.println("<h2>Password changed successfully!</h2>");
            } else {
                out.println("<h2>Student number not found!</h2>");
            }

            con.close();
        } catch(Exception e) {
            out.println("Error: " + e.getMessage());
        }
    }

    // redirect GET to a simple form page
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("change-pin.html");
    }
}