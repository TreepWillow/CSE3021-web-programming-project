package servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.*;

@WebServlet("/home")
public class DisplayInfoServlet extends HttpServlet {

    // This just loads the MySQL driver once when the servlet starts
    public void init() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        // Debug message
        //System.out.println("Entering DisplayInfoServlet");
        
        // If the user somehow reached this without logging in, send them back
        if (session == null || session.getAttribute("userId") == null) {
            response.sendRedirect("login.html");
            return;
        }

        int userId = (int) session.getAttribute("userId");

        // Variables to hold the values we want to show in home.jsp
        String studentName = "";
        String userName = "";
        String major = "Undeclared";
        String standing = "";
        String gpa = "";
        String cumulativeGPA = "";

        // classes
        String[] classList = new String[6];
        for (int i = 0; i < classList.length; i++) classList[i] = "";

        try (Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/banweb2db", "root", "1234")) {

            // Get username
            PreparedStatement userStmt = conn.prepareStatement(
                    "SELECT username FROM users WHERE id = ?");
            userStmt.setInt(1, userId);
            ResultSet userRs = userStmt.executeQuery();
            if (userRs.next()) {
                userName = userRs.getString("username");
            }

            // Get student info
            PreparedStatement stuStmt = conn.prepareStatement(
                    "SELECT student_name FROM students WHERE user_id = ?");
            stuStmt.setInt(1, userId);
            ResultSet stuRs = stuStmt.executeQuery();
            if (stuRs.next()) {
                studentName = stuRs.getString("student_name");
            }

            // Get classes for the student
            PreparedStatement regStmt = conn.prepareStatement(
                    "SELECT c.class_name FROM registered r " +
                    "JOIN classes c ON r.class_id = c.id " +
                    "WHERE r.student_id = (SELECT id FROM students WHERE user_id = ?)");
            regStmt.setInt(1, userId);
            ResultSet regRs = regStmt.executeQuery();

            int i = 0;
            while (regRs.next() && i < 6) {
                classList[i] = regRs.getString("class_name");
                i++;
            }

            // Dummy GPA values since DB doesn't have them yet
            gpa = "3.2";
            cumulativeGPA = "3.1";
            standing = "GOOD";

        } catch (Exception e) {
            e.printStackTrace();
        }

        // Send everything to the JSP
        request.setAttribute("userName", studentName);         // Student's real name
        request.setAttribute("userId", userName);              // Username = 900xxxxxx
        request.setAttribute("userMajor", major);              // Real major when added
        request.setAttribute("userStanding", standing);
        request.setAttribute("userGPA", gpa);
        request.setAttribute("userCumulativeGPA", cumulativeGPA);

        // Classes
        request.setAttribute("class1", classList[0]);
        request.setAttribute("class2", classList[1]);
        request.setAttribute("class3", classList[2]);
        request.setAttribute("class4", classList[3]);
        request.setAttribute("class5", classList[4]);
        request.setAttribute("class6", classList[5]);

        request.getRequestDispatcher("home.jsp").forward(request, response);

    }
}