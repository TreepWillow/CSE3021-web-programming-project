package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/LoginServlet") // URL that the login form posts to
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // This method handles the login form submission
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Get data from form
        String username = request.getParameter("user");
        String password = request.getParameter("password");

        if (username == null || password == null) {
            out.println("Please enter student number and password!");
            return;
        }

        try {
            // Connect to database
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/banweb2db", // put your DB name
                "root",                                      // your DB user
                "1234");                                 // your DB password

            // Check if student exists
            PreparedStatement stmt = con.prepareStatement(
                "SELECT * FROM users WHERE username=? AND pass=?");
            stmt.setString(1, username);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                out.println("<h2>Login Successful!</h2>");
                
                // Get userId from querry
                String userId = rs.getString(1);
                Integer int_user_id = Integer.parseInt(userId);
                
                
                // Create a Session and give it the user id
                HttpSession session = request.getSession();
                session.setAttribute("userId", int_user_id);
                
                
                response.sendRedirect("home");
            } else {
                out.println("<h2>Login Failed! Wrong student number or password.</h2>");
            }

            con.close();

        } catch (Exception e) {
            out.println("Error connecting to database: " + e.getMessage());
        }
    }

    // If someone just goes to /login, send them to the login page
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("login.html");
    }
}